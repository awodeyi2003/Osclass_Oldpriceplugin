Installation:
Just add the code to your theme for Listings
<span style="float:none" class="price">
<s>
<?php osc_run_hook('item_oldprice'); ?>
</s>
</span>
Just add the code to your theme for Premium
<span style="float:none" class="price">
<s>
<?php osc_run_hook('item_oldprice2'); ?>
</s>
</span>