<?php
/*
Plugin Name: Products attributes
Plugin URI: http://www.osclass.org/
Description: This plugin extends items price with items old price attributes for sales, special offer and so on.
Version: 0.0.1
Author: Adewale Emmanuel Awodeyi
Author URI: http://www.walexconcepts.com/
Short Name: products_plugin
Plugin update URI: products-attributes
*/


function products_call_after_install() {
    $conn = getConnection();

    $conn->autocommit(false);
    try {
        $path = osc_plugin_resource('products_attributes/struct.sql');
        $sql = file_get_contents($path);
        $conn->osc_dbImportSQL($sql);
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        echo $e->getMessage();
    }
    $conn->autocommit(true);

}

function products_call_after_uninstall() {
   $conn = getConnection();
    $conn->autocommit(false);
    try {
        $conn->osc_dbExec("DELETE FROM %st_plugin_category WHERE s_plugin_name = 'products_plugin'", DB_TABLE_PREFIX);
        $conn->osc_dbExec('DROP TABLE %st_item_products_attr', DB_TABLE_PREFIX);
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        echo $e->getMessage();
    }
    $conn->autocommit(true);

}

function products_form($catId = '') {
    // We received the categoryID
    if($catId!="") {
        // We check if the category is the same as our plugin
        if(osc_is_this_category('products_plugin', $catId)) {
            include_once 'item_edit.php';
        }
    }
}


function products_form_post($item) {
    // We received the categoryID and the Item ID
    if($item['fk_i_category_id']!=null) {
        // We check if the category is the same as our plugin
        if(osc_is_this_category('products_plugin', $item['fk_i_category_id'])) {
            $item_id = $item['pk_i_id'];
			$OldPrice = Params::getParam('OldPrice');
			$make = Params::getParam('make');
			$model = Params::getParam('model');
			$conn = getConnection();
            $conn->osc_dbExec("INSERT INTO oc_t_item_products_attr (
			fk_i_item_id,
			s_OldPrice) VALUES (
			'$item_id',
			'$OldPrice')", DB_TABLE_PREFIX);
     
		
		}
    }
}

// Self-explanatory
function products_item_detail() {
    if(osc_is_this_category('products_plugin', osc_item_category_id())) {
        $conn = getConnection();
        $detail = $conn->osc_dbFetchResult("SELECT * FROM %st_item_products_attr WHERE fk_i_item_id = %d", DB_TABLE_PREFIX, osc_item_id());
        if(isset($detail['fk_i_item_id'])) {
            //include_once 'item_detail.php';
        }
    }
}

// Self-explanatory
function products_item_oldprice2() {
        $conn = getConnection();
		$oldprice = $conn->osc_dbFetchResult("SELECT * FROM %st_item_products_attr WHERE fk_i_item_id = %d", DB_TABLE_PREFIX, osc_premium_id());
							if($oldprice['s_OldPrice']>0)  {
							$formatted = "₦" . number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $oldprice['s_OldPrice'])),2 );
  
							}else{$formatted='';}
							
							echo $formatted;
    
}



// Self-explanatory
function products_item_oldprice() {
       $conn = getConnection();
		$oldprice = $conn->osc_dbFetchResult("SELECT * FROM %st_item_products_attr WHERE fk_i_item_id = %d", DB_TABLE_PREFIX, osc_item_id());
							if($oldprice['s_OldPrice']>0)  {
							$formatted = "₦" . number_format(sprintf('%0.2f', preg_replace("/[^0-9.]/", "", $oldprice['s_OldPrice'])),2 );
  
							}else{$formatted='';}
							
							echo $formatted;
    
}

// Self-explanatory
function products_item_edit($catId = null, $item_id = null) {
    if(osc_is_this_category('products_plugin', $catId)) {
        $conn = getConnection();
        $detail = $conn->osc_dbFetchResult("SELECT * FROM %st_item_products_attr WHERE fk_i_item_id = %d", DB_TABLE_PREFIX, $item_id);
		if(isset($detail['fk_i_item_id'])) {
            include_once 'item_edit.php';
        }
    }
}

function products_item_edit_post($item) {
    // We received the categoryID and the Item ID
    if($item['fk_i_category_id']!=null) {
        // We check if the category is the same as our plugin
        if(osc_is_this_category('products_plugin', $item['fk_i_category_id'])) {
            $item_id = $item['pk_i_id'];
			$OldPrice = Params::getParam('OldPrice');
			$make = Params::getParam('make');
			$model = Params::getParam('model');
			$conn = getConnection();
			$conn->osc_dbExec("UPDATE oc_t_item_products_attr SET 
			s_OldPrice = '$OldPrice' 
			WHERE fk_i_item_id = '$item_id'", DB_TABLE_PREFIX);
             
        }
    }
}

function products_delete_item($item_id) {
    $conn = getConnection();
    $conn->osc_dbExec("DELETE FROM %st_item_products_attr WHERE fk_i_item_id = %d", DB_TABLE_PREFIX, $item_id);

}



function products_admin_configuration() {
    // Standard configuration page for plugin which extend item's attributes
    osc_plugin_configure_view(osc_plugin_path(__FILE__));
}

function products_pre_item_post() {
    Session::newInstance()->_setForm('pp_OldPrice' , Params::getParam('OldPrice'));
   	Session::newInstance()->_setForm('pp_make' , Params::getParam('make'));
    Session::newInstance()->_setForm('pp_model'   , Params::getParam('model'));
    // keep values on session
	Session::newInstance()->_keepForm('pp_OldPrice' );
	Session::newInstance()->_keepForm('pp_make' );
    Session::newInstance()->_keepForm('pp_model');
}

// This is needed in order to be able to activate the plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'products_call_after_install');
// This is a hack to show a Configure link at plugins table (you could also use some other hook to show a custom option panel)
osc_add_hook(osc_plugin_path(__FILE__)."_configure", 'products_admin_configuration');
// This is a hack to show a Uninstall link at plugins table (you could also use some other hook to show a custom option panel)
osc_add_hook(osc_plugin_path(__FILE__)."_uninstall", 'products_call_after_uninstall');

// When publishing an item we show an extra form with more attributes
osc_add_hook('item_form', 'products_form');
// To add that new information to our custom table
osc_add_hook('posted_item', 'products_form_post');

// When searching, display an extra form with our plugin's fields
osc_add_hook('search_form', 'products_search_form');
// When searching, add some conditions
osc_add_hook('search_conditions', 'products_search_conditions');

// Show an item special attributes
osc_add_hook('item_detail', 'products_item_detail');

// Show an item oldprice attributes
osc_add_hook('item_oldprice', 'products_item_oldprice');

// Show an item oldprice attributes
osc_add_hook('item_oldprice2', 'products_item_oldprice2');



// Edit an item special attributes
osc_add_hook('item_edit', 'products_item_edit');
// Edit an item special attributes POST
osc_add_hook('edited_item', 'products_item_edit_post');
//osc_add_hook('edited_post', 'products_item_edit_post');

//Delete item
osc_add_hook('delete_item', 'products_delete_item');

// previous to insert item
osc_add_hook('pre_item_post', 'products_pre_item_post') ;

?>
