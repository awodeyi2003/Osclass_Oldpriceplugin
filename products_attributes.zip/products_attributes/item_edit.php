<h3><?php _e('Products attributes', 'products_attributes') ; ?></h3>
<table>

	<tr>
        <?php
            if( Session::newInstance()->_getForm('pp_OldPrice') != '' ) {
                $detail['s_OldPrice'] = Session::newInstance()->_getForm('pp_OldPrice');
            }
        ?>
        <td><label for="OldPrice"><?php _e('OldPrice', 'products_attributes'); ?></label></td>
    	<td><input type="text" name="OldPrice" id="OldPrice" value="<?php if(@$detail['s_OldPrice'] != ''){echo @$detail['s_OldPrice']; } ?>" size="20" /></td>
    </tr>
	
	
	
    
</table>